9
-dotnetenterprise.s4net.scannerEngine.downloadCacheHit>
9dotnetenterprise.s4net.build.netcore_sdk_version.10_0_3001
text.civendor_semaphore06
.javascript.telemetry.typescript.native-previewtrue!
text.civendor_azurepipelines0"
jre_provisioning_disabledfalseF
>javascript.telemetry.typescript.compiler-options.noImplicitAnytrueB
=dotnetenterprise.s4net.build.override_warnings_as_errors.true1T
Odotnetenterprise.s4net.build.target_framework_moniker._netcoreapp_version_v10_01 
text.civendor_dockercompose06
)dotnetenterprise.s4net.serverInfo.product	SQ_ServerF
Adotnetenterprise.s4net.build.nuget_project_style.packagereference1F
=javascript.telemetry.typescript.compiler-options.alwaysStrictfalse%
 text.analyzed_hidden_files_count0F
(javascript.telemetry.typescript.versions6.0.3,7.0.0-dev.20260512.1#
javascript.runtime.version24.11M
Djavascript.telemetry.typescript.compiler-options.strictBindCallApplyfalse;
3dotnetenterprise.s4net.endstep.Sarif.v1_0_0_0.ValidTrueH
?javascript.telemetry.typescript.compiler-options.noImplicitThisfalse#
sonar.scanner.appScannerMSBuild
text.civendor_circleci0&
 javascript.runtime.major-version24
text.civendor_buildkite0/
$dotnetenterprise.s4net.begin.runtimenetcore5
)javascript.runtime.node-executable-originembeddedK
Ddotnetenterprise.s4net.params.sonar_cs_opencover_reportspaths.sourceCLI
text.civendor_travisci0%
text.sensor_time_ms_community5066=
2dotnetenterprise.s4net.scannerEngine.bootstrappingEnabled
text.civendor_jenkins0B
scanner.git_remote_url(https://github.com/valshre/Practicas.git@
8javascript.telemetry.typescript.compiler-options.allowJstrue'
!text.all_tracked_text_files_count79/
#dotnetenterprise.s4net.jre.downloadCacheHit6
,dotnetenterprise.s4net.build.msbuild_version18.6.3?
:javascript.telemetry.typescript.program-creation.attempted14
/dotnetenterprise.s4net.build.deterministic.true14
/javascript.telemetry.module-type.esm-file-count03
(dotnetenterprise.s4net.jre.bootstrappingEnabledB
4javascript.telemetry.typescript.compiler-options.lib
dom,esnextV
Mjavascript.telemetry.typescript.compiler-options.strictPropertyInitializationfalseT
Kjavascript.telemetry.typescript.compiler-options.useUnknownInCatchVariablesfalseM
Djavascript.telemetry.typescript.compiler-options.strictFunctionTypesfalse"
sonar.scanner.appVersion11.2.1
text.analyzed_files_count51>
9dotnetenterprise.s4net.build.using_microsoft_net_sdk.true1
text.civendor_appveyor0-
(text.secrets.disable_test_file_detection08
(javascript.telemetry.ecmascript.versionsnot-detectedJ
Ajavascript.telemetry.typescript.compiler-options.strictNullChecksfalse5
(dotnetenterprise.s4net.endstep.legacyTFS	NotCalled8
+dotnetenterprise.s4net.serverInfo.serverUrl	localhost<
7javascript.telemetry.typescript.program-creation.failed0@
7javascript.telemetry.typescript.compiler-options.strictfalse
text.civendor_bamboo0?
:javascript.telemetry.typescript.program-creation.succeeded1M
7dotnetenterprise.s4net.params.sonar_scm_disabled.sourceSQ_SERVER_SETTINGS
text.civendor_gitlab0:
2dotnetenterprise.s4net.build.visual_studio_version18.0;
2dotnetenterprise.s4net.endstep.coverage_conversionfalse%
 text.civendor_bitbucketpipelines0(
#text.secrets.disable_entropy_filter04
/javascript.telemetry.module-type.cjs-file-count0:
)dotnetenterprise.s4net.serverInfo.version26.6.0.123539(
#csharp.cs.language_version.csharp141U
Ljavascript.telemetry.typescript.compiler-options.strictBuiltinIteratorReturnfalse